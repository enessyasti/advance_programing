﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HomeFinances.Data;
using HomeFinances.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using HomeFinances.DTOs;

namespace HomeFinances.Controllers
{
    [Authorize]
    public class EntriesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private string GetUserId()
        {
            return User.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty;
        }

        public EntriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Entries
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Entry.Where(e => e.CreatedById == GetUserId()).Include(e => e.Category);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Entries/Create
        public IActionResult Create()
        {
            ViewData["CategoryId"] = new SelectList(_context.Category, "Id", "Name");
            return View();
        }

        // POST: Entries/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Amount,Date,CategoryId")] EntryDTO entryDTO)
        {
            Entry entry = new Entry()
            {
                Id = entryDTO.Id,
                Name = entryDTO.Name,
                Amount = entryDTO.Amount,
                Date = entryDTO.Date,
                CategoryId = entryDTO.CategoryId,
                CreatedById = GetUserId()
            };
            
            if (ModelState.IsValid)
            {    
                _context.Add(entry);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoryId"] = new SelectList(_context.Category, "Id", "Name", entry.CategoryId);
            return View(entry);
        }

        // GET: Entries/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var entry = await _context.Entry
                .Where(e => e.CreatedById == GetUserId())
                .FirstOrDefaultAsync(m => m.Id == id);
            if (entry == null)
            {
                return NotFound();
            }
            ViewData["CategoryId"] = new SelectList(_context.Category, "Id", "Name", entry.CategoryId);
            return View(entry);
        }

        // POST: Entries/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Amount,Date,CategoryId")] EntryDTO entryDTO)
        {
            if (id != entryDTO.Id)
            {
                return NotFound();
            }

            Entry entry = new Entry()
            {
                Id = entryDTO.Id,
                Name = entryDTO.Name,
                Amount = entryDTO.Amount,
                Date = entryDTO.Date,
                CategoryId = entryDTO.CategoryId,
                CreatedById = GetUserId()
            };

            if (!EntryExists(entry.Id, GetUserId()))
            {
                return NotFound();
            }


            if (ModelState.IsValid)
            {
                _context.Update(entry);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoryId"] = new SelectList(_context.Category, "Id", "Name", entry.CategoryId);
            return View(entry);
        }

        // GET: Entries/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var entry = await _context.Entry
                .Where(e => e.CreatedById == GetUserId())
                .Include(e => e.Category)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (entry == null)
            {
                return NotFound();
            }

            return View(entry);
        }

        // POST: Entries/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (EntryExists(id, GetUserId()))
            {
                var entry = await _context.Entry.FindAsync(id);
                _context.Entry.Remove(entry);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EntryExists(int id, string userId)
        {
            return _context.Entry.Any(e => e.Id == id && e.CreatedById == userId);
        }
    }
}
