﻿using Microsoft.AspNetCore.Identity;

namespace HomeFinances.Models
{
    public class AppUser : IdentityUser
    {
    }
}
