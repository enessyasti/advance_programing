﻿using HomeFinances.Models;
using System.ComponentModel.DataAnnotations;

namespace HomeFinances.DTOs
{
    public class EntryDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public float Amount { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}")]
        public DateOnly Date { get; set; }
        public int CategoryId { get; set; }
        public virtual Category? Category { get; set; }

        public EntryDTO() { }
        public EntryDTO(Entry entry)
        {
            Id = entry.Id;
            Name = entry.Name;
            Amount = entry.Amount;
            Date = entry.Date;
        }
    }
}
