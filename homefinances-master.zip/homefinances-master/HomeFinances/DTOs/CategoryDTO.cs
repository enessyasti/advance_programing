﻿using HomeFinances.Models;
using System.ComponentModel.DataAnnotations;

namespace HomeFinances.DTOs
{
    public class CategoryDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Color { get; set; }
        public ICollection<Entry> Entries { get; set; }
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public float Balance { get { return Entries.Sum(e => e.Amount); } }

        public CategoryDTO() { }
        public CategoryDTO(Category category)
        {
            Id = category.Id;
            Name = category.Name;
            Color = category.Color;
            Entries = category.Entries;
        }
    }
}
